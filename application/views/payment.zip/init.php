<?php
/**
 * Created by PhpStorm.
 * User: zxk
 * Date: 16/1/27
 * Time: 下午3:48
 */
$dir = dirname(__FILE__);

define("ROOTPATH", $dir);
?>